![js](\images\js.png)

Le projet Orinoco est un site de e_commerce.

Il contient 4 pages html liées entre elles.

Il utilise javascript côté client.

En démarrant de la page d'accueil index.html, où s'affichent tous les produits disponibles, on doit pouvoir accéder, dans l'ordre, aux pages:



   1 - products.html qui affiche la photo, le nom, le prix, les options disponibles, ainsi que la description du produit choisi en page d'accueil.

   2 - cart.html qui résume l'ensemble de la commande et affiche dans chaque ligne d'un tableau: l'article choisi, le prix de l'article, la quantité d'articles, ainsi que le coût par article.

Le coût total de la commande se fait dans la dernière colonne en additionant les coûts par article.

On y accède également au formulaire que le client doit remplir pour transmettre ses informations, à savoir: first name, last name, address, city, email.
 
   3 - confirmation.html où s'affichent, le remerciement du client, le N° de commande généré et le coût total de la commande.
